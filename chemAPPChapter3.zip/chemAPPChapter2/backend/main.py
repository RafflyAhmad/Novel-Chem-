from fastapi import FastAPI
from pydantic import BaseModel
from model import run_model
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class InputData(BaseModel):
    pic50_min: float
    pic50_max: float
    atom_min: float
    atom_max: float
    logP_min: float
    logP_max: float


@app.post("/predict")
def predict(data: InputData):
    """
    Main endpoint untuk generate dan evaluate chemical candidates
    """
    try:
        results = run_model(
            pic50_min=data.pic50_min,
            pic50_max=data.pic50_max,
            atom_min=int(data.atom_min),
            atom_max=int(data.atom_max),
            logP_min=data.logP_min,
            logP_max=data.logP_max
        )
        
        return {
            "success": True,
            "results": results
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "results": []
        }


@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "ok"}
