# model.py
import os
import json
import re
import base64
from io import BytesIO
from google import genai

# Try to import RDKit, but don't fail if it's missing. This lets the backend
# run for testing without requiring RDKit installation (useful on Windows).
try:
    from rdkit import Chem
    from rdkit.Chem import Draw
    RDKit_AVAILABLE = True
except Exception:
    RDKit_AVAILABLE = False

# Initialize Gemini client
API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyDfIuC3CrlD2EcNY6ZVeEVKt3NWy7Hguz8")
client = genai.Client(api_key=API_KEY)

def ask(prompt):
    """Call Gemini API untuk generate atau justify"""
    response = client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt
    )
    return response.text

def smiles_to_base64(smiles):
    """Convert SMILES string to base64 encoded PNG image"""
    try:
        if not RDKit_AVAILABLE:
            # RDKit not available — return None so frontend can handle missing images
            return None

        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return None

        img = Draw.MolToImage(mol, size=(300, 300))

        # Convert PIL image to base64
        img_buffer = BytesIO()
        img.save(img_buffer, format='PNG')
        img_buffer.seek(0)
        img_base64 = base64.b64encode(img_buffer.getvalue()).decode('utf-8')

        return f"data:image/png;base64,{img_base64}"
    except Exception as e:
        print(f"Error converting SMILES to image: {e}")
        return None

def evaluate_properties(pic50, atomNum, logp, pic50_min, pic50_max, atom_min, atom_max, logp_min, logp_max):
    """Evaluasi apakah properties memenuhi constraint"""
    return (
        pic50_min <= pic50 <= pic50_max and
        atom_min <= atomNum <= atom_max and
        logp_min <= logp <= logp_max
    )

def run_model(pic50_min, pic50_max, atom_min, atom_max, logP_min, logP_max):
    """
    Main model pipeline:
    1. Generate SMILES candidates dengan Gemini
    2. Assume predictions dari ML model (dummy untuk sekarang)
    3. Evaluate terhadap constraints
    4. Generate justifications
    5. Convert SMILES ke gambar base64
    """

    # Step 1: Generate SMILES candidates
    generation_prompt = f"""You are an agent meant to help scientist do in silico novel chemical discovery.
    Generate exactly 3 SMILES strings for novel chemical candidates that satisfy all constraints below. 
    Return ONLY a valid JSON list of SMILES strings.
    Do NOT add code fences, backticks, labels, explanation, or extra text.

    Constraints:
    - pIC50 range: {pic50_min} to {pic50_max}
    - Atom count: {atom_min} to {atom_max}
    - LogP range: {logP_min} to {logP_max}

    Act autonomously to propose valid, synthesizable structures. Do not justify.
    """
    
    try:
        generated_smiles_raw = ask(generation_prompt)
        json_str = re.search(r'\[.*\]', generated_smiles_raw, re.DOTALL).group(0)
        smiles_list = json.loads(json_str)
    except Exception as e:
        print(f"Error generating SMILES: {e}")
        smiles_list = []

    # Step 2 & 3: Dummy predictions (nanti ganti dengan model ML sebenarnya)
    dummy_predictions = [
        {"smiles": smiles_list[0] if len(smiles_list) > 0 else "O=C1NCCCCCC1Oc2ccc(C3=CC=CC=C3)cc2", "prediction": [0.87, 29, 4.6]},
        {"smiles": smiles_list[1] if len(smiles_list) > 1 else "O=C(O)C(C)(C)CCCOc1ccc(C2=CC=CC=C2)cc1", "prediction": [0.82, 27, 4.2]},
        {"smiles": smiles_list[2] if len(smiles_list) > 2 else "CCOc1ccc(C(=O)c2ccc(OCCC)cc2)cc1", "prediction": [0.91, 30, 4.8]}
    ]

    # Step 4: Evaluate dan filter
    valid_results = []
    for item in dummy_predictions:
        pic50, atomNum, logp = item["prediction"]
        
        if evaluate_properties(pic50, atomNum, logp, pic50_min, pic50_max, atom_min, atom_max, logP_min, logP_max):
            valid_results.append(item)

    # Step 5: Generate justifications dan images
    results = []
    for item in valid_results:
        smi = item["smiles"]
        props = item["prediction"]
        
        # Generate justification
        justify_prompt = f"""You are evaluating generated candidate chemicals. 
        Justify why the chemical with SMILES {smi}
        was selected based on its predicted properties: pIC50={props[0]}, Atom Count={props[1]}, LogP={props[2]}.

        Explain:
        1. How the predicted properties match the target constraints (pIC50: {pic50_min}-{pic50_max}, Atoms: {atom_min}-{atom_max}, LogP: {logP_min}-{logP_max}),
        2. Why this candidate is favorable,
        3. Any relevant chemical reasoning that supports the selection.

        Keep the explanation concise and technical. Max 3 sentences."""
        
        justification = ask(justify_prompt)
        
        # Convert SMILES to base64 image
        image_base64 = smiles_to_base64(smi)
        
        results.append({
            "smiles": smi,
            "properties": {
                "pic50": props[0],
                "atom_count": props[1],
                "logP": props[2]
            },
            "justification": justification,
            "image": image_base64
        })

    return results
