<template>
  <div class="min-h-screen bg-white relative">
    <div class="pt-20 flex flex-col lg:flex-row items-start justify-start px-5 lg:px-10 space-y-10 lg:space-y-0 lg:space-x-10">
      <div class="flex-shrink-0 w-full max-w-sm lg:max-w-md lg:w-auto lg:sticky lg:top-32">
        <img src="/molekul.png" class="w-full h-auto object-contain" alt="Molecule"/>
      </div>

      <div class="w-full flex-1 pr-10">
        <div class="mb-10">
          <h1 class="text-4xl font-extrabold text-gray-900 mb-2 text-center lg:text-left">Daftar Rekomendasi</h1>
          <div class="h-1 w-24 bg-[#4A70A9] mx-auto lg:mx-0"></div>
        </div>

        <div v-if="loading" class="text-center py-10">
          <p class="text-gray-600 text-lg">Loading recommendations...</p>
        </div>

        <div v-else-if="recommendations.length === 0" class="text-center py-10">
          <p class="text-gray-600 text-lg">Tidak ada rekomendasi yang sesuai dengan kriteria Anda Wleee Berjuang </p>
          <router-link to="/features" class="text-[#4A70A9] hover:underline mt-4 inline-block">
            Kembali ke pencarian Bissmilah
          </router-link>
        </div>

        <div v-else class="grid grid-cols-1 md:grid-cols-2 gap-8 justify-items-center lg:justify-items-start">
          <div v-for="(item, index) in recommendations" :key="index"
               class="bg-white shadow-lg rounded-xl p-5 w-72 flex flex-col items-center">
            
           
            <div class="w-full h-40 bg-gray-200 flex items-center justify-center rounded-md overflow-hidden">
              <img v-if="item.image" :src="item.image" alt="Molecule"
                   class="object-contain h-full w-full"/>
              <p v-else class="text-gray-600 text-sm">Gambar Senyawa</p>
            </div>

           
            <div class="mt-4 w-full text-left text-sm space-y-2">
              <div class="border-b pb-2">
                <p class="text-gray-600"><span class="font-semibold">SMILES:</span> {{ item.smiles }}</p>
              </div>
              <div class="border-b pb-2">
                <p class="text-gray-700"><span class="font-semibold">pIC50:</span> {{ item.properties.pic50 }}</p>
                <p class="text-gray-700"><span class="font-semibold">Atom Count:</span> {{ item.properties.atom_count }}</p>
                <p class="text-gray-700"><span class="font-semibold">LogP:</span> {{ item.properties.logP }}</p>
              </div>
              <div class="py-2">
                <p class="text-gray-600"><span class="font-semibold">Justifikasi:</span></p>
                <p class="text-gray-700 italic">{{ item.justification }}</p>
              </div>
            </div>
          
            <button
              @click="goDetail(item)"
              class="mt-5 bg-[#4A70A9] text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-900">
              Lihat Lebih Detail
            </button>
          </div>
        </div>
      </div>
    </div>

    <div class="fixed bottom-0 right-0 w-20 h-20 bg-[#4A70A9] rounded-tl-full"></div>
  </div>
</template>

<script setup>
import Navbar from '../components/Navbar.vue'
import { useRouter, useRoute } from 'vue-router'
import { ref, onMounted } from 'vue'

const router = useRouter()
const route = useRoute()

const recommendations = ref([])
const loading = ref(false)

onMounted(() => {
  if (route.params.results) {
    try {
      recommendations.value = JSON.parse(route.params.results)
    } catch (err) {
      console.error('Error parsing results:', err)
    }
  } else if (route.query.results) {
    try {
      recommendations.value = JSON.parse(route.query.results)
    } catch (err) {
      console.error('Error parsing results:', err)
    }
  }
})

function goDetail(item) {
  router.push({
    path: '/detail',
    query: { smiles: item.smiles }
  })
}
</script>